package com.zeker.test;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestLog {

    private Logger log = LoggerFactory.getLogger(TestLog.class);

    @Test
    public void testLog(){

        log.debug("debug");

        log.debug("info");

        log.debug("warn");

        log.debug("error");
    }
}
