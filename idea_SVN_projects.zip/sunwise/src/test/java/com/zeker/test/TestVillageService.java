package com.zeker.test;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zeker.pojo.Village;
import com.zeker.service.VillageService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring/applicationContext.xml")
public class TestVillageService {

    @Autowired
    private VillageService villageService;

    @Test//查询
    public void find(){
        Village village = villageService.getById(1L);//单个id查询
        System.out.println(village);

        List<Village> villages = villageService.listByIds(Arrays.asList(1L, 3L));//多个id查询
        System.out.println(villages);

        List<Village> villageList = villageService.list();//查询所有
        System.out.println(villageList);

    }

    @Test//插入和根据id修改
    public void add(){

            Village village = new Village( null,"gzg", "x005", "xx", 1, 1, "xx", "xx", new Date(), new Date());
//             villageService.save(village);
             villageService.updateById(village);


//        for (int i=0;i<20;i++) { 插入二十条
//            Village village = new Village(6L+Long.valueOf(i), "gzg"+i, "x005", "xx", 1, 1, "xx", "xx", new Date(), new Date());
//            villageService.save(village);
//        }
    }

    @Test//删除
    public void delete(){

        boolean b = villageService.removeById(4L);//根据id删除
    }

    @Test
    public void testPage(){//分页查询

        //创建分页条件
        //(开始页数，分页大小)
        Page<Village> page = new Page<>(1, 5);

        Page<Village> villagePage = villageService.page(page);

        System.out.println(villagePage.getTotal());
        System.out.println(villagePage.getRecords());

    }

    @Test
    public void testQueryWrapper(){
        QueryWrapper<Village> queryWrapper = new QueryWrapper<>();

        QueryWrapper<Village> wrapper = queryWrapper.like("name", "gzg").ge("id",20);//查询name中带有gzg的，且id>=20的
        List<Village> list = villageService.list(wrapper);

        System.out.println(list);
    }

    @Test
    public void findQuery(){

        QueryWrapper<Village> queryWrapper=new QueryWrapper<>();

        String name="果";

        Page<Village> page=new Page(1,5);

        if(!StringUtils.isEmpty(name)){//如果name为空则执行下面的条件，不等于空则执行查询第一页的五条数据
            queryWrapper.like("name",name);
        }

        Page<Village> villagePage = villageService.page(page, queryWrapper);
        System.out.println(villagePage.getRecords());
        System.out.println(villagePage.getTotal());

    }

    @Test
    public void testLambdaQueryWrapper(){//lambda写法

        LambdaQueryWrapper<Village> lambdaQueryWrapper=new LambdaQueryWrapper<>();

        String name="果";

        //方法引用，链式编程
        lambdaQueryWrapper.like(!StringUtils.isEmpty(name),Village::getName,"果").gt(Village::getId,30);

        List<Village> villageList = villageService.list(lambdaQueryWrapper);

        System.out.println(villageList);

    }


}
