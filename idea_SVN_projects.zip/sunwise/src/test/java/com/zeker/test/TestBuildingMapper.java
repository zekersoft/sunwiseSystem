package com.zeker.test;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zeker.mapper.BuildingMapper;
import com.zeker.pojo.dto.BuildingDto;
import com.zeker.pojo.vo.BuildingVo;
import org.apache.ibatis.annotations.Param;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Created by zeker on 2022/1/29 16:46
 *
 * @Description
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring/applicationContext.xml")
public class TestBuildingMapper {

    @Autowired
    private BuildingMapper buildingMapper;

    @Test
    public void testFind(){
        Page page = new Page(1,4);

        BuildingVo buildingVo = new BuildingVo();
        buildingVo.setVillageName("gzg");

        Page<BuildingDto> buildingPageByQueryVo = buildingMapper.findBuildingPageByQueryVo(page,buildingVo);

        System.out.println(buildingPageByQueryVo);
    }


}
