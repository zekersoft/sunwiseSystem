package com.zeker.test;

import com.zeker.mapper.VillageMapper;
import com.zeker.pojo.Village;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.*;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring/applicationContext.xml")
public class TestVillageMapper {

    @Autowired
    private VillageMapper villageMapper;

    @Test//插入和修改
    public void testAdd(){
        Village village = new Village(null,"xx", "x003", "xx", 1, 1, "xx", "xx", new Date(), new Date());
//        villageMapper.updateById(village);//根据id进行修改
        villageMapper.insert(village);//插入
    }

    @Test//根据id进行查询
    public void selectId(){
        Village village = villageMapper.selectById(2L);
        System.out.println(village);
    }

    @Test//查询所有
    public void selectAll(){
        List<Village> villages = villageMapper.selectList(null);
        System.out.println(villages);
    }

    @Test
    public void selectByIds(){
        List<Village> villages = villageMapper.selectBatchIds(Arrays.asList(1L, 3L));//根据id集合查询
        System.out.println(villages);
    }

    @Test//将查询条件集放进map集合进行查询
    public void selectIdByMap(){

        Map<String, Object> map = new HashMap<>();
        map.put("name","猪猪");

        List<Village> villages = villageMapper.selectByMap(map);
        System.out.println(villages);
    }

    @Test//根据id删除，不需要提交，框架已经实现
    public void deletById(){

        int i = villageMapper.deleteById(4L);
    }


}
