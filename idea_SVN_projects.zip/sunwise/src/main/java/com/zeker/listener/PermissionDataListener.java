package com.zeker.listener;

/**
 * Created by zeker on 2022/2/13 20:41
 *
 * @Description
 */

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.zeker.pojo.Permission;
import com.zeker.pojo.data.PermissionData;
import com.zeker.service.PermissionService;
import com.zeker.utils.JsonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PermissionDataListener extends AnalysisEventListener<PermissionData> {


    private Logger log= LoggerFactory.getLogger(PermissionDataListener.class);

    /**
     * 每隔5条存储数据库，实际使用中可以100条，然后清理list ，方便内存回收
     */
    private static final int BATCH_COUNT = 100;

    private PermissionService permissionService;

    /**
     * 缓存的数据
     */
    private List<PermissionData> cachedDataList = new ArrayList<PermissionData>(BATCH_COUNT);

    /**
     * 如果使用了spring,请使用这个构造方法。每次创建Listener的时候需要把spring管理的类传进来
     *
     * @param permissionService
     */
    public PermissionDataListener(PermissionService permissionService) {
        this.permissionService = permissionService;
    }

    /**
     * 这个每一条数据解析都会来调用
     *
     * @param data    one row value. Is is same as {@link AnalysisContext#readRowHolder()}
     * @param context
     */
    @Override
    public void invoke(PermissionData data, AnalysisContext context) {
        log.info("解析到一条数据:{}", JsonUtils.objectToJson(data));
        cachedDataList.add(data);
        // 达到BATCH_COUNT了，需要去存储一次数据库，防止数据几万条数据在内存，容易OOM
        if (cachedDataList.size() >= BATCH_COUNT) {

            //当list集合缓存数据达到100，保存一次
            saveData();
            // 存储完成清理 list
            cachedDataList = new ArrayList<>(BATCH_COUNT);
        }
    }

    /**
     * 所有数据解析完成了 都会来调用
     *
     * @param context
     */
    @Override
    public void doAfterAllAnalysed(AnalysisContext context) {
        // 这里也要保存数据，确保最后遗留的数据也存储到数据库
        saveData();
        log.info("所有数据解析完成！");
    }

    /**
     * 加上存储数据库
     */
    private void saveData() {
        log.info("{}条数据，开始存储数据库！", cachedDataList.size());

        cachedDataList.stream().forEach(permissionData -> {
            Permission permission=new Permission();
            BeanUtils.copyProperties(permissionData,permission);
            permission.setCreated(new Date());
            permission.setUpdated(new Date());
            permissionService.save(permission);
        });
        log.info("存储数据库成功！");
    }
}

