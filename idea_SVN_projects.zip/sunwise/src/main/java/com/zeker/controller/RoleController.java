package com.zeker.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zeker.pojo.Role;
import com.zeker.pojo.dto.RoleListDto;
import com.zeker.pojo.vo.RoleVo;
import com.zeker.result.MessageCode;
import com.zeker.result.Result;
import com.zeker.result.ResultUtils;
import com.zeker.service.RoleService;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Controller
@ResponseBody//流形式返回
@RequestMapping("/role")
@Api(tags = "角色相关接口")
public class RoleController {

    @Autowired
    private RoleService roleService;

    @ApiOperation(value = "list接口",notes = "带分页的模糊查询",httpMethod ="GET")//接口名介绍
    @ApiImplicitParams(value = {//请求参数——转中文
            @ApiImplicitParam(name = "page",value = "页数",required = true,paramType = "query",dataType = "Integer"),
            @ApiImplicitParam(name = "limit",value = "分页条件",required = true,paramType = "query",dataType = "Integer"),
            @ApiImplicitParam(name = "villageName",value = "小区名称查询条件",paramType ="query",dataType = "string"),
            @ApiImplicitParam(name = "roleName",value = "角色查询条件",paramType ="query",dataType = "string")
    }
    )
    @ApiResponses(  value = {//响应状态码——转中文
            @ApiResponse(code = 200,message = "请求成功"),
            @ApiResponse(code = 404,message = "请求路径没有或者页面跳转路径不对"),
            @ApiResponse(code = 400,message = "请求参数没填好")
    }
    )
    @RequestMapping(value = "/list",method = RequestMethod.GET)//映射路径
    public Result list(RoleVo roleVo){

        //调用service进行模糊的分页查询

        //构建分页条件
        Page<Role> page = new Page<>(roleVo.getPage(), roleVo.getLimit());
        IPage<RoleListDto> roleList = roleService.findRoleList(page, roleVo);

        //封装结果集对象
        return ResultUtils.buildSuccess(roleList.getTotal(),roleList.getRecords());

    }

    //添加小区
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    @ApiOperation(value = "add接口",notes = "增加角色",httpMethod ="POST")
    public Result add(@RequestBody @ApiParam(value = "新增角色参数",name = "Role") Role role){
        //角色的添加中，需要增加权限；涉及到角色表、角色权限中间表
        roleService.insertRoleAndRolePermission(role);

        return ResultUtils.buildSuccess();
    }

    //修改小区
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    @ApiOperation(value = "update接口",notes = "修改角色",httpMethod ="POST" )
    public Result update(@RequestBody Role role){

        roleService.updateRoleAndRolePermission(role);
        return ResultUtils.buildSuccess();

    }

    //根据id删除小区
    @RequestMapping(value = "/deleteById",method = RequestMethod.GET)
    @ApiOperation(value = "deleteById接口",notes = "删除",httpMethod = "GET")
    public Result deleteById(@RequestParam Long id){

        if (id==null){
            return ResultUtils.buildFail(MessageCode.ID_NOT_EMPTY);
        }
        roleService.removeById(id);
        return ResultUtils.buildSuccess();

    }


    //批量删除
    @RequestMapping(value = "/batchDelete",method = RequestMethod.GET)
    @ApiOperation(value = "batchDelete接口",notes = "批量删除",httpMethod = "GET")
    public Result batchDelete(@RequestParam String ids ){//ids表前端发过来的选中的行数，实际是一个数组

        //将选中的数据，也就是ids，拆分后合并成一个数组。
        List<Long> list = Stream.of(ids.split(",")).map(id -> Long.valueOf(id)).collect(Collectors.toList());

        roleService.removeByIds(list);
        return ResultUtils.buildSuccess();
    }

    //查看
    @RequestMapping(value = "/find/{id}",method = RequestMethod.GET)
    @ApiOperation(value = "find/{id}接口",notes = "查看角色",httpMethod = "GET")
    public Result findById(@PathVariable("id") Long id){

        Role role = roleService.getById(id);
        return ResultUtils.buildSuccess(role);
    }
}
