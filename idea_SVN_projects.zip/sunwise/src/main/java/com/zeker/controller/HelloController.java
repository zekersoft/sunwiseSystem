package com.zeker.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Created by zeker on 2022/1/30 15:23
 *
 * @Description
 */

@Controller
@Api(tags = "测试swagger")
public class HelloController {

    @RequestMapping(value = "/hello",method = RequestMethod.GET)
    @ResponseBody
    @ApiOperation(value = "hello接口",notes = "xxxx",httpMethod = "GET")
    public String hello(){

        return "hello";
    }


}
