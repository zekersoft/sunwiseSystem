package com.zeker.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sun.tools.internal.xjc.reader.xmlschema.BindGreen;
import com.zeker.exception.CustomerException;
import com.zeker.pojo.Admin;
import com.zeker.pojo.dto.AdminDto;
import com.zeker.pojo.dto.LoginDto;
import com.zeker.pojo.vo.AdminVo;
import com.zeker.result.MessageCode;
import com.zeker.result.Result;
import com.zeker.result.ResultUtils;
import com.zeker.service.AdminService;
import com.zeker.service.impl.AdminServiceImpl;
import com.zeker.utils.WebUtils;
import io.swagger.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.BindingResultUtils;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Controller
@ResponseBody//流形式返回
@RequestMapping("/admin")
@Api(tags = "管理员相关接口")
public class AdminController {

    @Autowired
    private AdminService adminService;

    private Logger log= LoggerFactory.getLogger(AdminController.class);

    @ApiOperation(value = "list接口",notes = "带分页的模糊查询",httpMethod ="GET")//接口名介绍
    @ApiImplicitParams(value = {//请求参数——转中文
            @ApiImplicitParam(name = "page",value = "页数",required = true,paramType = "query",dataType = "Integer"),
            @ApiImplicitParam(name = "limit",value = "分页条件",required = true,paramType = "query",dataType = "Integer"),
            @ApiImplicitParam(name = "villageName",value = "小区名称查询条件",paramType ="query",dataType = "string"),
            @ApiImplicitParam(name = "adminName",value = "管理员查询条件",paramType ="query",dataType = "string")
    }
    )
    @ApiResponses(  value = {//响应状态码——转中文
            @ApiResponse(code = 200,message = "请求成功"),
            @ApiResponse(code = 404,message = "请求路径没有或者页面跳转路径不对"),
            @ApiResponse(code = 400,message = "请求参数没填好")
    }
    )
    @RequestMapping(value = "/list",method = RequestMethod.GET)//映射路径
    public Result list(AdminVo adminVo){

        //调用service进行模糊的分页查询

        //构建分页条件
        Page<Admin> adminPage = new Page<>(adminVo.getPage(), adminVo.getLimit());
        LambdaQueryWrapper<Admin> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.like(!StringUtils.isEmpty(adminVo.getName()),Admin::getName,adminVo.getName());
        Page<Admin> page = adminService.page(adminPage, lambdaQueryWrapper);

        //封装结果集对象
        return ResultUtils.buildSuccess(page.getTotal(),page.getRecords());

    }

    //添加小区
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    @ApiOperation(value = "add接口",notes = "增加管理员",httpMethod ="POST")
    public Result add(@RequestBody @ApiParam(value = "新增管理员参数",name = "Admin") @Validated AdminDto adminDto, BindingResult bindingResult){
        //1.校验

        //是否有错误
        if(bindingResult.hasErrors()){
            return WebUtils.getErrors(bindingResult);
        }


        if(!adminDto.getPassword().equals(adminDto.getPassword2())){
            log.info("两次密码不一致");
            throw new CustomerException(MessageCode.TWO_PASSWORD_NO_EQUALS);
        }
        //2.调用service
        adminService.addAdmin(adminDto);

        return ResultUtils.buildSuccess();
    }



    //修改小区
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    @ApiOperation(value = "update接口",notes = "修改管理员",httpMethod ="POST" )
    public Result update(@RequestBody Admin admin){

        admin.setUpdated(new Date());
        adminService.updateById(admin);
        return ResultUtils.buildSuccess();

    }

    //根据id删除小区
    @RequestMapping(value = "/deleteById",method = RequestMethod.GET)
    @ApiOperation(value = "deleteById接口",notes = "删除",httpMethod = "GET")
    public Result deleteById(@RequestParam Long id){

        if (id==null){
            return ResultUtils.buildFail(MessageCode.ID_NOT_EMPTY);
        }
        adminService.removeById(id);
        return ResultUtils.buildSuccess();

    }


    //批量删除
    @RequestMapping(value = "/batchDelete",method = RequestMethod.GET)
    @ApiOperation(value = "batchDelete接口",notes = "批量删除",httpMethod = "GET")
    public Result batchDelete(@RequestParam String ids ){//ids表前端发过来的选中的行数，实际是一个数组

        //将选中的数据，也就是ids，拆分后合并成一个数组。
        List<Long> list = Stream.of(ids.split(",")).map(id -> Long.valueOf(id)).collect(Collectors.toList());

        adminService.removeByIds(list);
        return ResultUtils.buildSuccess();
    }

    //查看
    @RequestMapping(value = "/find/{id}",method = RequestMethod.GET)
    @ApiOperation(value = "find/{id}接口",notes = "查看管理员",httpMethod = "GET")
    public Result findById(@PathVariable("id") Long id){

        Admin admin = adminService.getById(id);
        return ResultUtils.buildSuccess(admin);
    }

    //登录
    @ApiOperation(value = "管理员的登录",notes = "管理员的登录")
    @RequestMapping(value = "/login",method = RequestMethod.POST)
    public Result login(@RequestBody  @Validated LoginDto loginDto, BindingResult bindingResult){

        if(bindingResult.hasErrors()){
            return WebUtils.getErrors(bindingResult);
        }
        String token = adminService.login(loginDto);
        return ResultUtils.buildSuccess(token);
    }


}
