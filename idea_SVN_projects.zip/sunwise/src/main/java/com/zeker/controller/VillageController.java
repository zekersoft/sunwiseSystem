package com.zeker.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zeker.pojo.Village;
import com.zeker.pojo.vo.VillageVo;
import com.zeker.result.MessageCode;
import com.zeker.result.Result;
import com.zeker.result.ResultUtils;
import com.zeker.service.VillageService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections4.ResettableListIterator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Controller
@ResponseBody
@RequestMapping("/village")
@Api(tags = "小区相关接口")
public class VillageController {

    @Autowired
    private VillageService villageService;

    @ApiOperation(value = "list接口",notes = "带分页的查询",httpMethod ="GET")
    @RequestMapping(value = "/list",method = RequestMethod.GET)
    public Result list(VillageVo villageVo){

        //调用service进行模糊的分页查询

        //构建分页条件
        Page<Village> villagePage = new Page<>(villageVo.getPage(), villageVo.getLimit());
        LambdaQueryWrapper<Village> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.like(!StringUtils.isEmpty(villageVo.getName()),Village::getName,villageVo.getName());
        Page<Village> page = villageService.page(villagePage, lambdaQueryWrapper);

//        int x = 1/0;//异常测试
        //封装结果集对象
       return ResultUtils.buildSuccess(page.getTotal(),page.getRecords());
    }

    //添加小区
    @ApiOperation(value = "add接口",notes = "增加小区",httpMethod ="POST")
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public Result add(@RequestBody Village village){

        village.setCreated(new Date());
        village.setUpdated(village.getCreated());
        villageService.save(village);
        return ResultUtils.buildSuccess();
    }

    //修改小区
    @ApiOperation(value = "update接口",notes = "修改小区",httpMethod = "POST")
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public Result update(@RequestBody Village village){

        village.setUpdated(new Date());
        villageService.updateById(village);
        return ResultUtils.buildSuccess();

    }

    //根据id删除小区
    @ApiOperation(value = "deleteById接口",notes = "根据id删除小区",httpMethod = "GET")
    @RequestMapping(value = "/deleteById",method = RequestMethod.GET)
    public Result deleteById(@RequestParam Long id){

        if (id==null){
            return ResultUtils.buildFail(MessageCode.ID_NOT_EMPTY);
        }
        villageService.removeById(id);
        return ResultUtils.buildSuccess();

    }


    //批量删除小区
    @ApiOperation(value = "batchDelete接口",notes = "批量删除小区",httpMethod = "GET")
    @RequestMapping(value = "/batchDelete",method = RequestMethod.GET)
    public Result batchDelete(@RequestParam String ids ){//ids表前端发过来的选中的行数，实际是一个数组

        //将选中的数据，也就是ids，拆分后合并成一个数组。
        List<Long> list = Stream.of(ids.split(",")).map(id -> Long.valueOf(id)).collect(Collectors.toList());

        villageService.removeByIds(list);
        return ResultUtils.buildSuccess();
    }

    //查看
    @ApiOperation(value = "find/{id}接口",notes = "查看",httpMethod = "GET")
    @RequestMapping(value = "/find/{id}",method = RequestMethod.GET)
    public Result findById(@PathVariable("id") Long id){

        Village village = villageService.getById(id);

        return ResultUtils.buildSuccess(village);
    }
}
