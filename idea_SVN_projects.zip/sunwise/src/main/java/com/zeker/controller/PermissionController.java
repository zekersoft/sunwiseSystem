package com.zeker.controller;

import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zeker.listener.PermissionDataListener;
import com.zeker.pojo.Permission;
import com.zeker.pojo.data.PermissionData;
import com.zeker.pojo.vo.PermissionVo;
import com.zeker.result.MessageCode;
import com.zeker.result.Result;
import com.zeker.result.ResultUtils;
import com.zeker.service.PermissionService;
import io.swagger.annotations.*;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Controller
@ResponseBody//流形式返回
@RequestMapping("/permission")
@Api(tags = "权限相关接口")
public class PermissionController {

    @Autowired
    private PermissionService permissionService;

    @ApiOperation(value = "list接口",notes = "带分页的模糊查询",httpMethod ="GET")//接口名介绍
    @ApiImplicitParams(value = {//请求参数——转中文
            @ApiImplicitParam(name = "page",value = "页数",required = true,paramType = "query",dataType = "Integer"),
            @ApiImplicitParam(name = "limit",value = "分页条件",required = true,paramType = "query",dataType = "Integer"),
            @ApiImplicitParam(name = "villageName",value = "小区名称查询条件",paramType ="query",dataType = "string"),
            @ApiImplicitParam(name = "permissionName",value = "权限查询条件",paramType ="query",dataType = "string")
    }
    )
    @ApiResponses(  value = {//响应状态码——转中文
            @ApiResponse(code = 200,message = "请求成功"),
            @ApiResponse(code = 404,message = "请求路径没有或者页面跳转路径不对"),
            @ApiResponse(code = 400,message = "请求参数没填好")
    }
    )
    @RequestMapping(value = "/list",method = RequestMethod.GET)//映射路径
    public Result list(PermissionVo permissionVo){

        //调用service进行模糊的分页查询

        //构建分页条件
        Page<Permission> permissionPage = new Page<>(permissionVo.getPage(), permissionVo.getLimit());
        LambdaQueryWrapper<Permission> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.like(!StringUtils.isEmpty(permissionVo.getName()),Permission::getName,permissionVo.getName());
        Page<Permission> page = permissionService.page(permissionPage, lambdaQueryWrapper);

        //封装结果集对象
        return ResultUtils.buildSuccess(page.getTotal(),page.getRecords());
    }

    //为角色管理——新增——查询所有权限

    @RequestMapping(value = "/all",method = RequestMethod.GET)//映射路径
    public Result all(){
        List<Permission> permissionList = permissionService.list();
        //封装结果集对象
        return ResultUtils.buildSuccess(permissionList);
    }

    @RequestMapping(value = "/findPermissionByRoleId",method = RequestMethod.GET)//映射路径
    public Result findPermissionByRoleId(Long roleId){
        List<Permission> permissionByRoleIdList = permissionService.findPermissionByRoleId(roleId);
        //封装结果集对象
        return ResultUtils.buildSuccess(permissionByRoleIdList);
    }



    //添加小区
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    @ApiOperation(value = "add接口",notes = "增加权限",httpMethod ="POST")
    public Result add(@RequestBody @ApiParam(value = "新增权限参数",name = "Permission") Permission permission){

        permission.setCreated(new Date());
        permission.setUpdated(permission.getCreated());
        permissionService.save(permission);
        return ResultUtils.buildSuccess();
    }

    //修改小区
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    @ApiOperation(value = "update接口",notes = "修改权限",httpMethod ="POST" )
    public Result update(@RequestBody Permission permission){

        permission.setUpdated(new Date());
        permissionService.updateById(permission);
        return ResultUtils.buildSuccess();

    }

    //根据id删除小区
    @RequestMapping(value = "/deleteById",method = RequestMethod.GET)
    @ApiOperation(value = "deleteById接口",notes = "删除",httpMethod = "GET")
    public Result deleteById(@RequestParam Long id){

        if (id==null){
            return ResultUtils.buildFail(MessageCode.ID_NOT_EMPTY);
        }
        permissionService.removeById(id);
        return ResultUtils.buildSuccess();

    }


    //批量删除
    @RequestMapping(value = "/batchDelete",method = RequestMethod.GET)
    @ApiOperation(value = "batchDelete接口",notes = "批量删除",httpMethod = "GET")
    public Result batchDelete(@RequestParam String ids ){//ids表前端发过来的选中的行数，实际是一个数组

        //将选中的数据，也就是ids，拆分后合并成一个数组。
        List<Long> list = Stream.of(ids.split(",")).map(id -> Long.valueOf(id)).collect(Collectors.toList());

        permissionService.removeByIds(list);
        return ResultUtils.buildSuccess();
    }

    @RequestMapping(value = "/export",method = RequestMethod.GET)
    public void download(HttpServletResponse response, PermissionVo permissionVo) throws IOException {
        // 这里注意 有同学反应使用swagger 会导致各种问题，请直接用浏览器或者用postman
        response.setContentType("application/vnd.ms-excel");
        response.setCharacterEncoding("utf-8");
        // 这里URLEncoder.encode可以防止中文乱码 当然和easyexcel没有关系
        String fileName = URLEncoder.encode("权限列表", "UTF-8");
        response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");

        //查询所有的权限
        LambdaQueryWrapper<Permission> lambdaQueryWrapper=new LambdaQueryWrapper<>();
        lambdaQueryWrapper.like(!StringUtils.isEmpty(permissionVo.getName()),Permission::getName,permissionVo.getName());

        List<Permission> permissionList = permissionService.list(lambdaQueryWrapper);

        List<PermissionData> dataList = permissionList.stream().map(permission -> {
            PermissionData permissionData = new PermissionData();
            BeanUtils.copyProperties(permission, permissionData);
            return permissionData;
        }).collect(Collectors.toList());

        EasyExcel.write(response.getOutputStream(), PermissionData.class).sheet("班长").doWrite(dataList);
    }

    /**
     * 文件上传
     * <p>1. 创建excel对应的实体对象 参照{@link PermissionData}
     * <p>2. 由于默认一行行的读取excel，所以需要创建excel一行一行的回调监听器，参照{@link PermissionDataListener}
     * <p>3. 直接读即可
     */
    @RequestMapping(value = "/import",method = RequestMethod.POST)
    @ResponseBody
    public String upload(MultipartFile file) throws IOException {
        EasyExcel.read(file.getInputStream(), PermissionData.class, new PermissionDataListener(permissionService)).sheet().doRead();
        return "success";
    }

    //查看
    @RequestMapping(value = "/find/{id}",method = RequestMethod.GET)
    @ApiOperation(value = "find/{id}接口",notes = "查看权限",httpMethod = "GET")
    public Result findById(@PathVariable("id") Long id){

        Permission permission = permissionService.getById(id);
        return ResultUtils.buildSuccess(permission);
    }
}
