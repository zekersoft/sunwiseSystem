package com.zeker.controller;

import com.zeker.result.Result;
import com.zeker.result.ResultUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

@Controller
@ResponseBody
@RequestMapping("/upload")
@Api(tags = "图片上传接口")
public class UploadController {

    private Logger log = LoggerFactory.getLogger(UploadController.class);



    //所有的上传图片都可以用这个接口
    //还需要在apringmvc中配置
    @RequestMapping(value = "/image",method = RequestMethod.POST)
    @ApiOperation(value ="image接口",notes = "图片上传接口",httpMethod = "GET")
    public Result uploadImage(@RequestParam MultipartFile image) throws IOException {//image是前端发过来的参数
        String originalFilename = image.getOriginalFilename();//拿到文件名

        log.debug("原文件名：{}",originalFilename);
        String extName = originalFilename.substring(originalFilename.lastIndexOf("."));//获取后缀

        log.debug("后缀名：{}",extName);
        String newImageName = UUID.randomUUID().toString().replace("-", "")+extName;//获取一个uuid,拼接上后缀，组成一个新文件名

        log.debug("新名字：{}",newImageName);
        //设置存储路径
        String path = "D:\\code\\image";

        log.info("存储路径：{}",path);

        //存储图片
        image.transferTo(new File(path+File.separator+newImageName));

//        返回前端，图片的访问路径
        String url = "http://image.sunwise.com/";
        log.debug("图片的访问路径:{}",url);

        return ResultUtils.buildSuccess(url+newImageName);//返回图片的访问路径给前端

    }

}
