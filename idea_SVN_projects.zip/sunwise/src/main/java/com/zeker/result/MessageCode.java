package com.zeker.result;

public enum MessageCode {

    REQUEST_SUCCESS(0,"请求成功!"),
    ID_NOT_EMPTY(50001,"ID不能为空!"),
    UN_KNOW_EXCEPTION(50000,"系统繁忙，请待会再来！"),
    USERNAME_EXITS(50002,"用户名已存在！"),
    PHONE_EXITS(50003,"手机号已存在！"),
    EMAIL_EXITS(50002,"邮箱已存在！"),
    TWO_PASSWORD_NO_EQUALS(50004,"密码不一致！"),
    USERNAME_OR_PASSWORD_ERROR(50005,"用户名或密码错误"),
    TOKEN_NOT_EMPTY(50006,"token不能为空"),
    TOKEN_ERROR(50007,"非法token!!!"),
    NO_PERMISSION(50008,"没有权限");

    //提示信息
    private String msg;

    //响应的状态码
    private Integer code;

    private MessageCode(Integer code,String msg){
        this.msg=msg;
        this.code=code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }
}
