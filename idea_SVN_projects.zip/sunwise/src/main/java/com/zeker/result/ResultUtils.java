package com.zeker.result;


//构建成功引用带分页
public class ResultUtils {

    public static Result buildSuccess(Long count,Object data){

        Result result =new Result();
        result.setCode(MessageCode.REQUEST_SUCCESS.getCode());
        result.setMsg(MessageCode.REQUEST_SUCCESS.getMsg());
        result.setCount(count);
        result.setData(data);
        return  result;

    }

    //构建单个结果的成功
    public static Result buildSuccess(Object data){
        return buildSuccess(null,data);
    }

    //不带数据请求返回的请求成功
    public static Result buildSuccess(){
        return buildSuccess(null);
    }


    //构建失败信息
    public static Result buildFail(MessageCode messageCode){
        Result result =new Result();
        result.setCode(messageCode.getCode());
        result.setMsg(messageCode.getMsg());
        return result;
    }

    public static Result buildFail(Integer code,String message){
        return new Result(code, message, null, null);
    }
}
