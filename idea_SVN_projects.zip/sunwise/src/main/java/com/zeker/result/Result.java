package com.zeker.result;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "响应信息")
public class Result<T> {


    @ApiModelProperty("响应状态码")
    private Integer code;//响应状态码

    @ApiModelProperty("响应信息")
    private String msg;//响应信息

    @ApiModelProperty("总记录数")
    private Long count;//总记录数

    @ApiModelProperty("返回的数据")
    private T data;//返回的数据

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Long getCount() {
        return count;
    }

    public void setCount(Long count) {
        this.count = count;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public Result(Integer code, String msg, Long count, T data) {
        this.code = code;
        this.msg = msg;
        this.count = count;
        this.data = data;
    }

    public Result() {
    }
}
