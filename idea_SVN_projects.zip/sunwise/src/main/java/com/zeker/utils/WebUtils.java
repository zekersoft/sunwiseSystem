package com.zeker.utils;

import com.zeker.result.Result;
import com.zeker.result.ResultUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;

import java.util.List;

/**
 * Created by zeker on 2022/2/7 16:59
 *
 * @Description
 */
public class WebUtils {

    /**
     * 处理校验失败的信息
     * @param bindingResult
     * @return
     */
    public static Result getErrors(BindingResult bindingResult) {
        List<ObjectError> allErrors = bindingResult.getAllErrors();

        StringBuffer sb = new StringBuffer();

        for (ObjectError objectError:allErrors){
            String defaultMessage = objectError.getDefaultMessage();
            sb.append(defaultMessage+",");
        }
        return ResultUtils.buildFail(50006,sb.toString().substring(0,sb.toString().length()-1));
    }

}
