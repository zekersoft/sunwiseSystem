package com.zeker.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zeker.pojo.Building;
import com.zeker.pojo.Person;
import com.zeker.pojo.dto.PersonDto;
import com.zeker.pojo.vo.Person_Car_ParkingPlace_ParkingUsed_Vo;

/**
 * Created by zeker on 2022/2/14 0:00
 *
 * @Description
 */
public interface PersonMapper extends BaseMapper<Person> {

    public Page<PersonDto> findPersonPageByQueryVo(Page page, Person_Car_ParkingPlace_ParkingUsed_Vo person_car_parkingPlace_parkingUsed_vo);

}
