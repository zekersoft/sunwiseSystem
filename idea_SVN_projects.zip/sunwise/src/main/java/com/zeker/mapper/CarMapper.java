package com.zeker.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zeker.pojo.Building;
import com.zeker.pojo.Car;
import com.zeker.pojo.dto.CarDto;
import com.zeker.pojo.vo.Person_Car_ParkingPlace_ParkingUsed_Vo;
import org.apache.ibatis.annotations.Param;

/**
 * Created by zeker on 2022/2/13 23:59
 *
 * @Description
 */
public interface CarMapper extends BaseMapper<Car> {

    public Page<CarDto> findCarPageByQueryVo(Page page, @Param("person_car_parkingPlace_parkingUsed_vo") Person_Car_ParkingPlace_ParkingUsed_Vo person_car_parkingPlace_parkingUsed_vo);

}
