package com.zeker.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zeker.pojo.Permission;
import com.zeker.pojo.Role;

import java.awt.*;
import java.util.List;

/**
 * Created by zeker on 2022/2/6 22:35
 *
 * @Description
 */
public interface PermissionMapper extends BaseMapper<Permission> {


    //根据角色Id查询权限
    public List<Permission> findPermissionByRoleId(Long roleId);

    //根据管理员的名字查询对应的权限
    public List<Permission> findPermissionByAdminUsername(String username);



}
