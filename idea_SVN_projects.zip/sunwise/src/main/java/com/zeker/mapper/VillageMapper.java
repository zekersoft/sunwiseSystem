package com.zeker.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zeker.pojo.Village;

public interface VillageMapper extends BaseMapper<Village> {
//继承了BaseMapper后，可以实现单表的增删改查，不用写代码了。但是多表不行。
}
