package com.zeker.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zeker.pojo.House;
import com.zeker.pojo.dto.HouseDto;
import com.zeker.pojo.vo.HouseVo;
import org.apache.ibatis.annotations.Param;


public interface HouseMapper  extends BaseMapper<House> {

    public Page<HouseDto> findHousePageByQueryVo(Page page, @Param("houseVo") HouseVo houseVo);
}
