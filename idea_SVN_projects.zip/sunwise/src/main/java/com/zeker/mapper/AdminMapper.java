package com.zeker.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zeker.pojo.Admin;

/**
 * Created by zeker on 2022/2/6 22:35
 *
 * @Description
 */
public interface AdminMapper extends BaseMapper<Admin> {

}
