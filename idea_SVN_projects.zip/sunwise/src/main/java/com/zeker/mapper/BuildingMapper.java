package com.zeker.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zeker.pojo.Building;
import com.zeker.pojo.dto.BuildingDto;
import com.zeker.pojo.vo.BuildingVo;
import org.apache.ibatis.annotations.Param;


public interface BuildingMapper extends BaseMapper<Building> {

    /**
     * @param page  //携带分页信息
     * @param buildingVo
     * @return  //MP语法，返回一个page,放的就是BuildingDto；
     */
    public Page<BuildingDto> findBuildingPageByQueryVo(Page page,@Param("buildingVo") BuildingVo buildingVo);
}
