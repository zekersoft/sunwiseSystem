package com.zeker.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zeker.pojo.Building;
import com.zeker.pojo.ParkingUsed;
import com.zeker.pojo.dto.ParkingPlaceDto;
import com.zeker.pojo.dto.ParkingUsedDto;
import com.zeker.pojo.vo.Person_Car_ParkingPlace_ParkingUsed_Vo;

/**
 * Created by zeker on 2022/2/14 0:01
 *
 * @Description
 */
public interface ParkingUsedMapper extends BaseMapper<ParkingUsed> {

    public Page<ParkingUsedDto> findParkingUsedPageByQueryVo(Page page, Person_Car_ParkingPlace_ParkingUsed_Vo person_car_parkingPlace_parkingUsed_vo);

}
