package com.zeker.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zeker.pojo.RolePermission;

/**
 * Created by zeker on 2022/2/16 2:25
 *
 * @Description
 */
public interface RolePermissionMapper extends BaseMapper<RolePermission> {



}
