package com.zeker.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zeker.pojo.Admin;
import com.zeker.pojo.Role;
import com.zeker.pojo.dto.RoleListDto;
import com.zeker.pojo.vo.RoleVo;
import org.apache.ibatis.annotations.Param;

/**
 * Created by zeker on 2022/2/6 22:35
 *
 * @Description
 */
public interface RoleMapper extends BaseMapper<Role> {

    /**
     * 角色列表
     * @param page
     * @param roleVo
     * @return
     */
    public IPage<RoleListDto> findRoleList(Page<Role> page,@Param("roleVo") RoleVo roleVo);

}
