package com.zeker.interceptor;

import com.zeker.pojo.dto.AdminDto;

/**
 * Created by zeker on 2022/2/7 22:52
 *
 * @Description
 */
public class AdminThreadLocal {

    private static ThreadLocal<AdminDto> tl=new ThreadLocal<>();

    /**
     * 绑定用户信息到当前线程
     * @param adminDto
     */
    public static void setAdminDto(AdminDto adminDto){
        tl.set(adminDto);
    }

    /**
     * 获取当前线程绑定的用户
     * @return
     */
    public static AdminDto getAdminDto(){
        return tl.get();
    }


    /**
     * 移除当前线程绑定的信息
     */
    public static  void removeAdminDto(){
        tl.remove();
    }

}
