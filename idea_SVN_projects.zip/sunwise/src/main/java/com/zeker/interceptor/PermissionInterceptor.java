package com.zeker.interceptor;

import com.zeker.result.MessageCode;
import com.zeker.result.ResultUtils;
import com.zeker.service.PermissionService;
import com.zeker.utils.JsonUtils;
import com.zeker.utils.ResponseUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by zeker on 2022/2/16 19:59
 *
 * @Description
 */
public class PermissionInterceptor implements HandlerInterceptor {

    private Logger log = LoggerFactory.getLogger(PermissionInterceptor.class);

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        //不需要拦截的资源直接在配置中进行配置
        //获取当前访问的uri地址
        String uri = request.getRequestURI();

        log.debug("当前访问的接口地址是：{}",uri);

        //查询当前用户拥有的权限，jwt进行处理，认证拦截器已经解析了权限信息绑定到了当前线程，直接获取

        //判断当前用户是否访问当前uri的权限，有就放行，没有就拦截

        //判断当前用户是否是超级管理员，如果是，不做权限鉴定
        if (AdminThreadLocal.getAdminDto().getUsername().equals("admin")){
            log.debug("超级管理员直接放行");
            return true;

        }

        //获取用户拥有的权限
        boolean isOk = false;

        String permissionUris = AdminThreadLocal.getAdminDto().getPermissionUris();//获取所有权限uri
        if (!StringUtils.isEmpty(permissionUris)){
            String[] permissionArray = permissionUris.split(",");
//            System.out.println(permissionArray.toString());//断点插桩
            for (String permissionUri:permissionArray){
                //如果当前访问的uri忽然permissionUri相等就意味着有权限
                if (uri.equals(permissionUri)){
                    isOk=true;
                    break;
                }

            }
        }

        if (!isOk){
            log.debug("没有权限...");
            ResponseUtils.responseToJson(JsonUtils.objectToJson(ResultUtils.buildFail(MessageCode.NO_PERMISSION)),response);
            return false;
        }




        return true;

    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

    }
}
