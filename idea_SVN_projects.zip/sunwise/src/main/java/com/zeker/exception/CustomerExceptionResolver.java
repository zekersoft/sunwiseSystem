package com.zeker.exception;

import com.baomidou.mybatisplus.core.toolkit.BeanUtils;
import com.zeker.result.MessageCode;
import com.zeker.result.Result;
import com.zeker.result.ResultUtils;
import com.zeker.utils.JsonUtils;
import com.zeker.utils.ResponseUtils;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CustomerExceptionResolver implements HandlerExceptionResolver {


    @Override
    public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception exception) {

        String msg;
        Integer code;

        //判断是否为自定义异常
        if (exception instanceof CustomerException){
            CustomerException customerException = (CustomerException)exception;
            msg=customerException.getMessageCode().getMsg();
            code=customerException.getMessageCode().getCode();
        }else{
            exception.printStackTrace();
            msg= MessageCode.UN_KNOW_EXCEPTION.getMsg();
            code=MessageCode.UN_KNOW_EXCEPTION.getCode();
        }

        Result result = ResultUtils.buildFail(code,msg);

        //发送数据给前端
        ResponseUtils.responseToJson(JsonUtils.objectToJson(result),response);

        ModelAndView modelAndView = new ModelAndView();
        return modelAndView;
    }




}
