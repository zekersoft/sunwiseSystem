package com.zeker.exception;

import com.zeker.result.MessageCode;

public class CustomerException extends RuntimeException {

    private MessageCode messageCode;

    public CustomerException(MessageCode messageCode){

        super(messageCode.getMsg());
        this.messageCode=messageCode;

    }

    public MessageCode getMessageCode() {
        return messageCode;
    }

    public void setMessageCode(MessageCode messageCode) {
        this.messageCode = messageCode;
    }
}
