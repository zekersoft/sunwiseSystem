package com.zeker.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zeker.mapper.AdminMapper;
import com.zeker.mapper.RoleMapper;
import com.zeker.mapper.RolePermissionMapper;
import com.zeker.pojo.Admin;
import com.zeker.pojo.Role;
import com.zeker.pojo.RolePermission;
import com.zeker.pojo.dto.RoleListDto;
import com.zeker.pojo.vo.RoleVo;
import com.zeker.service.AdminService;
import com.zeker.service.PermissionService;
import com.zeker.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Date;

/**
 * Created by zeker on 2022/2/6 22:37
 *
 * @Description
 */
@Service
public class RoleServiceImpl extends ServiceImpl<RoleMapper,Role> implements RoleService{

    @Autowired
    private RolePermissionMapper rolePermissionMapper;

    @Override
    public IPage<RoleListDto> findRoleList(Page<Role> page, RoleVo roleVo) {
        return getBaseMapper().findRoleList(page,roleVo);
    }

    @Override
    public void insertRoleAndRolePermission(Role role) {
        //1.插入角色的基本信息
        role.setCreated(new Date());
        role.setUpdated(role.getCreated());
        this.save(role);

        //2.维护角色和权限的中间表，往中间表插入数据
        if (!StringUtils.isEmpty(role.getPermissionIds())){
            //如果不为空，则代表有权限，需要维护权限关系

            String[] permissionIds = role.getPermissionIds().split(",");
            for (String pId:permissionIds){

                RolePermission rolePermission = new RolePermission();
                rolePermission.setRoleId(role.getId());
                rolePermission.setPermissionId(Long.valueOf(pId));
                //插入角色和权限
                rolePermissionMapper.insert(rolePermission);

            }

        }

    }

    @Override
    public void updateRoleAndRolePermission(Role role) {
//        修改角色的基本信息

        role.setUpdated(new Date());
        this.updateById(role);
//        要维护角色和权限的中间表
//        先删除角色对应的权限
        LambdaQueryWrapper<RolePermission> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(RolePermission::getRoleId,role.getId());
        rolePermissionMapper.delete(lambdaQueryWrapper);
        //添加新权限

    }

}
