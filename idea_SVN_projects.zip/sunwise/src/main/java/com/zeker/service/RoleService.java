package com.zeker.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zeker.pojo.Admin;
import com.zeker.pojo.Role;
import com.zeker.pojo.dto.RoleListDto;
import com.zeker.pojo.vo.RoleVo;
import org.apache.ibatis.annotations.Param;

/**
 * Created by zeker on 2022/2/6 22:36
 *
 * @Description
 */
public interface RoleService extends IService<Role> {

    public IPage<RoleListDto> findRoleList(Page<Role> page, @Param("roleVo") RoleVo roleVo);

    public void insertRoleAndRolePermission(Role role);

    //修改角色以及对应的权限
    public void updateRoleAndRolePermission(Role role);

}
