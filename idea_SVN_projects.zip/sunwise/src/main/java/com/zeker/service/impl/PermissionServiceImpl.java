package com.zeker.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zeker.mapper.PermissionMapper;
import com.zeker.pojo.Permission;
import com.zeker.service.PermissionService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by zeker on 2022/2/6 23:55
 *
 * @Description
 */
@Service
public class PermissionServiceImpl extends ServiceImpl<PermissionMapper, Permission> implements PermissionService {

    @Override
    public List<Permission> findPermissionByRoleId(Long roleId) {

        return getBaseMapper().findPermissionByRoleId(roleId);
    }
}
