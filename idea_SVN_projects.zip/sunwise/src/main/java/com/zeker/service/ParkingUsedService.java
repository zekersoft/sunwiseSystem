package com.zeker.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zeker.pojo.ParkingUsed;
import com.zeker.pojo.Person;
import com.zeker.pojo.dto.ParkingUsedDto;
import com.zeker.pojo.dto.PersonDto;
import com.zeker.pojo.vo.Person_Car_ParkingPlace_ParkingUsed_Vo;
import org.apache.ibatis.annotations.Param;

/**
 * Created by zeker on 2022/2/14 0:12
 *
 * @Description
 */
public interface ParkingUsedService extends IService<ParkingUsed> {

    public Page<ParkingUsedDto> findParkingUsedPageByQueryVo(Page page, @Param("person_car_parkingPlace_parkingUsed_vo") Person_Car_ParkingPlace_ParkingUsed_Vo person_car_parkingPlace_parkingUsed_vo);

}
