package com.zeker.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zeker.mapper.HouseMapper;
import com.zeker.mapper.VillageMapper;
import com.zeker.pojo.House;
import com.zeker.pojo.Village;
import com.zeker.pojo.dto.HouseDto;
import com.zeker.pojo.vo.HouseVo;
import com.zeker.service.HouseService;
import com.zeker.service.VillageService;
import org.springframework.stereotype.Service;

/**
 * Created by zeker on 2022/2/4 23:51
 *
 * @Description
 */
@Service
public class HouseServiceImpl extends ServiceImpl<HouseMapper, House> implements HouseService {

    @Override
    public Page<HouseDto> findHousePageByQueryVo(Page page, HouseVo houseVo) {
        return getBaseMapper().findHousePageByQueryVo(page,houseVo);
    }
}
