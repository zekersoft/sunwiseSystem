package com.zeker.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zeker.mapper.ParkingPlaceMapper;
import com.zeker.mapper.PersonMapper;
import com.zeker.pojo.ParkingPlace;
import com.zeker.pojo.Person;
import com.zeker.pojo.dto.ParkingPlaceDto;
import com.zeker.pojo.vo.Person_Car_ParkingPlace_ParkingUsed_Vo;
import com.zeker.service.ParkingPlaceService;
import org.springframework.stereotype.Service;

/**
 * Created by zeker on 2022/2/14 0:31
 *
 * @Description
 */
@Service
public class ParkingPlaceServiceImpl extends ServiceImpl<ParkingPlaceMapper, ParkingPlace> implements ParkingPlaceService {

    @Override
    public Page<ParkingPlaceDto> findParkingPlacePageByQueryVo(Page page, Person_Car_ParkingPlace_ParkingUsed_Vo person_car_parkingPlace_parkingUsed_vo) {
        return getBaseMapper().findParkingPlacePageByQueryVo(page,person_car_parkingPlace_parkingUsed_vo);
    }
}
