package com.zeker.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zeker.mapper.CarMapper;
import com.zeker.mapper.HouseMapper;
import com.zeker.pojo.Car;
import com.zeker.pojo.House;
import com.zeker.pojo.dto.CarDto;
import com.zeker.pojo.vo.Person_Car_ParkingPlace_ParkingUsed_Vo;
import com.zeker.service.CarService;
import org.springframework.stereotype.Service;

/**
 * Created by zeker on 2022/2/14 0:03
 *
 * @Description
 */
@Service
public class CarServiceImpl extends ServiceImpl<CarMapper, Car> implements CarService {

    @Override
    public Page<CarDto> findCarPageByQueryVo(Page page, Person_Car_ParkingPlace_ParkingUsed_Vo person_car_parkingPlace_parkingUsed_vo) {
        return getBaseMapper().findCarPageByQueryVo(page,person_car_parkingPlace_parkingUsed_vo);
    }
}
