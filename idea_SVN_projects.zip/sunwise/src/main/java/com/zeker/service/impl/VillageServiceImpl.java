package com.zeker.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zeker.mapper.VillageMapper;
import com.zeker.pojo.Village;
import com.zeker.service.VillageService;
import org.springframework.stereotype.Service;

@Service
public class VillageServiceImpl extends ServiceImpl<VillageMapper,Village> implements VillageService {
//实现接口，并继承ServiceImpl实现类(是一个通用类)
//ServiceImpl<VillageMapper,Village>中告诉操作的mapper是VillageMapper和pojo类是Village

}
