package com.zeker.service.impl;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zeker.mapper.HouseMapper;
import com.zeker.mapper.PersonMapper;
import com.zeker.pojo.House;
import com.zeker.pojo.Person;
import com.zeker.pojo.dto.PersonDto;
import com.zeker.pojo.vo.Person_Car_ParkingPlace_ParkingUsed_Vo;
import com.zeker.service.PersonService;
import org.springframework.stereotype.Service;

/**
 * Created by zeker on 2022/2/14 0:13
 *
 * @Description
 */
@Service
public class PersonServiceImpl extends ServiceImpl<PersonMapper, Person> implements PersonService {

    @Override
    public Page<PersonDto> findPersonPageByQueryVo(Page page, Person_Car_ParkingPlace_ParkingUsed_Vo person_car_parkingPlace_parkingUsed_vo) {
        return getBaseMapper().findPersonPageByQueryVo(page,person_car_parkingPlace_parkingUsed_vo);
    }
}
