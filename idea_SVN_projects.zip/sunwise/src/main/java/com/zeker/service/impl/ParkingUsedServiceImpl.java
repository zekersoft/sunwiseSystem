package com.zeker.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zeker.mapper.ParkingUsedMapper;
import com.zeker.pojo.ParkingUsed;
import com.zeker.pojo.dto.ParkingUsedDto;
import com.zeker.pojo.vo.Person_Car_ParkingPlace_ParkingUsed_Vo;
import com.zeker.service.ParkingUsedService;
import org.springframework.stereotype.Service;

/**
 * Created by zeker on 2022/2/14 0:39
 *
 * @Description
 */
@Service
public class ParkingUsedServiceImpl extends ServiceImpl<ParkingUsedMapper, ParkingUsed> implements ParkingUsedService {

    @Override
    public Page<ParkingUsedDto> findParkingUsedPageByQueryVo(Page page, Person_Car_ParkingPlace_ParkingUsed_Vo person_car_parkingPlace_parkingUsed_vo) {
        return getBaseMapper().findParkingUsedPageByQueryVo(page,person_car_parkingPlace_parkingUsed_vo);
    }
}
