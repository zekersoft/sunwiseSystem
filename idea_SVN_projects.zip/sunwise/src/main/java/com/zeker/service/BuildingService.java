package com.zeker.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zeker.pojo.Building;
import com.zeker.pojo.dto.BuildingDto;
import com.zeker.pojo.vo.BuildingVo;
import org.apache.ibatis.annotations.Param;

public interface BuildingService extends IService<Building> {

    public Page<BuildingDto> findBuildingPageByQueryVo(Page page, @Param("buildingVo") BuildingVo buildingVo);

}
