package com.zeker.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zeker.pojo.House;
import com.zeker.pojo.Village;
import com.zeker.pojo.dto.BuildingDto;
import com.zeker.pojo.dto.HouseDto;
import com.zeker.pojo.vo.BuildingVo;
import com.zeker.pojo.vo.HouseVo;
import org.apache.ibatis.annotations.Param;

/**
 * Created by zeker on 2022/2/4 23:49
 *
 * @Description
 */
public interface HouseService extends IService<House> {

    public Page<HouseDto> findHousePageByQueryVo(Page page, @Param("houseVo") HouseVo houseVo);

}
