package com.zeker.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zeker.exception.CustomerException;
import com.zeker.mapper.AdminMapper;
import com.zeker.mapper.PermissionMapper;
import com.zeker.pojo.Admin;
import com.zeker.pojo.Permission;
import com.zeker.pojo.dto.AdminDto;
import com.zeker.pojo.dto.LoginDto;
import com.zeker.result.MessageCode;
import com.zeker.service.AdminService;
import com.zeker.utils.Md5Utils;
import com.zeker.utils.TokenUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * Created by zeker on 2022/2/6 22:37
 *
 * @Description
 */
/**
 * Created by zxd on 2022/1/20 14:15
 */
@Service
public class AdminServiceImpl extends ServiceImpl<AdminMapper, Admin> implements AdminService {

    private Logger log= LoggerFactory.getLogger(AdminServiceImpl.class);

    @Autowired
    private PermissionMapper permissionMapper;

    @Override
    public void addAdmin(AdminDto adminDto) {

        //我们现在接收的是dto，但是保存的是pojo,怎么办?
        Admin admin=new Admin();
        BeanUtils.copyProperties(adminDto,admin);

        //判断账户相关信息是否重复

        //判断用户名是否重复
        LambdaQueryWrapper<Admin> usernameLambdaQueryWrapper=new LambdaQueryWrapper<>();
        usernameLambdaQueryWrapper.eq(Admin::getUsername,adminDto.getUsername());
        //如果查询到了账户，代表重复添加
        if(getBaseMapper().selectOne(usernameLambdaQueryWrapper)!=null){
            log.info("用户名已经存在:{}",adminDto.getUsername());
            throw new CustomerException(MessageCode.USERNAME_EXITS);
        }

        //判断手机号码是否重复 TODO
        LambdaQueryWrapper<Admin> phoneLambdaQueryWrapper=new LambdaQueryWrapper<>();
        phoneLambdaQueryWrapper.eq(Admin::getPhone,adminDto.getPhone());
        //如果查询到了，代表重复添加
        if(getBaseMapper().selectOne(phoneLambdaQueryWrapper)!=null){
            log.info("手机号码已经存在:{}",adminDto.getPhone());
            throw new CustomerException(MessageCode.PHONE_EXITS);
        }


        //判断邮箱是否重复 TODO
        LambdaQueryWrapper<Admin> emailLambdaQueryWrapper=new LambdaQueryWrapper<>();
        emailLambdaQueryWrapper.eq(Admin::getEmail,adminDto.getEmail());
        //如果查询到了，代表重复添加
        if(getBaseMapper().selectOne(emailLambdaQueryWrapper)!=null){
            log.info("手机号码已经存在:{}",adminDto.getEmail());
            throw new CustomerException(MessageCode.EMAIL_EXITS);
        }

        //生成盐
        String salt = Md5Utils.createSalt();


        //盐和密码进行加密
        String md5Password = Md5Utils.md5Password(admin.getPassword(), salt);

        //设置盐和加密后的密码到pojo中
        admin.setSalt(salt);
        admin.setPassword(md5Password);
        admin.setCreated(new Date());
        admin.setUpdated(admin.getCreated());

        //保存数据到数据库
        getBaseMapper().insert(admin);

        //添加管理员对应的角色




    }

    @Override
    public String login(LoginDto loginDto) {
        //1.使用用户名查询用户信息
        LambdaQueryWrapper<Admin> usernameLambdaQueryWrapper=new LambdaQueryWrapper<>();
        usernameLambdaQueryWrapper.eq(Admin::getUsername,loginDto.getUsername());
        Admin admin = getBaseMapper().selectOne(usernameLambdaQueryWrapper);

        if(admin==null){
            log.info("用户名不存在!");
            throw new CustomerException(MessageCode.USERNAME_OR_PASSWORD_ERROR);
        }

        //2.获取盐，对用户输入的密码进行再次的加密
        String md5Password = Md5Utils.md5Password(loginDto.getPassword(), admin.getSalt());

        //3.对比密码是否一致，一致登录成功
        if(!md5Password.equals(admin.getPassword())){
            log.info("密码错误!");
            throw new CustomerException(MessageCode.USERNAME_OR_PASSWORD_ERROR);
        }

        List<Permission> permissionList = permissionMapper.findPermissionByAdminUsername(admin.getUsername());
        StringBuffer sb = new StringBuffer();
        permissionList.forEach(permission -> {
            sb.append(permission.getUri()+",");
        });

        //4.登录成功后，生成jwt令牌，返回给客户端
        String token = TokenUtils.token(admin.getName(), admin.getPhone(), admin.getImage(), admin.getUsername(), admin.getEmail(),sb.toString());

        return token;
    }
}

