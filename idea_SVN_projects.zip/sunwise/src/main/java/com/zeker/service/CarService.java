package com.zeker.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zeker.pojo.Car;
import com.zeker.pojo.House;
import com.zeker.pojo.dto.CarDto;
import com.zeker.pojo.dto.HouseDto;
import com.zeker.pojo.vo.HouseVo;
import com.zeker.pojo.vo.Person_Car_ParkingPlace_ParkingUsed_Vo;
import org.apache.ibatis.annotations.Param;

/**
 * Created by zeker on 2022/2/14 0:03
 *
 * @Description
 */
public interface CarService extends IService<Car> {

    public Page<CarDto> findCarPageByQueryVo(Page page, @Param("person_car_parkingPlace_parkingUsed_vo") Person_Car_ParkingPlace_ParkingUsed_Vo person_car_parkingPlace_parkingUsed_vo);

}
