package com.zeker.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zeker.pojo.ParkingPlace;
import com.zeker.pojo.Person;
import com.zeker.pojo.dto.ParkingPlaceDto;
import com.zeker.pojo.dto.PersonDto;
import com.zeker.pojo.vo.Person_Car_ParkingPlace_ParkingUsed_Vo;

/**
 * Created by zeker on 2022/2/14 0:30
 *
 * @Description
 */
public interface ParkingPlaceService extends IService<ParkingPlace> {

    public Page<ParkingPlaceDto> findParkingPlacePageByQueryVo(Page page, Person_Car_ParkingPlace_ParkingUsed_Vo person_car_parkingPlace_parkingUsed_vo);

}
