package com.zeker.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zeker.pojo.Permission;
import com.zeker.pojo.Role;

import java.util.List;

/**
 * Created by zeker on 2022/2/6 22:36
 *
 * @Description
 */
public interface PermissionService extends IService<Permission> {

    //根据角色Id查询权限
    public List<Permission> findPermissionByRoleId(Long roleId);

}
