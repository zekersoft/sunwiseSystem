package com.zeker.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zeker.mapper.BuildingMapper;
import com.zeker.pojo.Building;
import com.zeker.pojo.dto.BuildingDto;
import com.zeker.pojo.vo.BuildingVo;
import com.zeker.service.BuildingService;
import org.springframework.stereotype.Service;

@Service
public class BuildingServiceImpl extends ServiceImpl<BuildingMapper, Building> implements BuildingService {
    @Override
    public Page<BuildingDto> findBuildingPageByQueryVo(Page page, BuildingVo buildingVo) {
        return getBaseMapper().findBuildingPageByQueryVo(page,buildingVo);
    }
}
