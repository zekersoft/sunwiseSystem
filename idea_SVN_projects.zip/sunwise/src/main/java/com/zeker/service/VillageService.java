package com.zeker.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zeker.pojo.Village;

public interface VillageService extends IService<Village>  {
//实现mybatisplus提供的接口IService，接口中已经有写好的方法
}
