package com.zeker.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zeker.pojo.Admin;
import com.zeker.pojo.dto.AdminDto;
import com.zeker.pojo.dto.LoginDto;

/**
 * Created by zeker on 2022/2/6 22:36
 *
 * @Description
 */
public interface AdminService extends IService<Admin> {

    /**
     * 添加账户
     * @param adminDto
     */
    public void addAdmin(AdminDto adminDto);

    /**
     *登录
     * @param loginDto
     * @return jwt令牌
     */
    public String login(LoginDto loginDto);

}
