package com.zeker.pojo.data;

import com.alibaba.excel.annotation.ExcelProperty;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by zeker on 2022/2/6 22:16
 *
 * @Description
 */
@TableName("zeker_permission")
public class PermissionData implements Serializable {


    @ExcelProperty("权限名称")
    private String name;

    @ExcelProperty("权限uri")
    private String uri;

    @ExcelProperty("权限标记")
    private String tag;

    @ExcelProperty("创建时间")
    private Date created;



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }


}
