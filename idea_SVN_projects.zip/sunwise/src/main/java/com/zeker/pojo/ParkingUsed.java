package com.zeker.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.util.Date;

/**
 * Created by zeker on 2022/2/13 23:06
 *
 * @Description
 */
@TableName("zeker_parkingused")
public class ParkingUsed {

    @TableId(type = IdType.INPUT)
    private Long id;

    private Long car_id;

    private Long parkingplace_id;

    private Long person_id;

    private Long village_id;

    private String be_used;

    private double cost;

    private Date began;

    private Date ended;

    private Date created;

    private String car_number;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCar_id() {
        return car_id;
    }

    public void setCar_id(Long car_id) {
        this.car_id = car_id;
    }

    public Long getParkingplace_id() {
        return parkingplace_id;
    }

    public void setParkingplace_id(Long parkingplace_id) {
        this.parkingplace_id = parkingplace_id;
    }

    public Long getPerson_id() {
        return person_id;
    }

    public void setPerson_id(Long person_id) {
        this.person_id = person_id;
    }

    public Long getVillage_id() {
        return village_id;
    }

    public void setVillage_id(Long village_id) {
        this.village_id = village_id;
    }

    public String getBe_used() {
        return be_used;
    }

    public void setBe_used(String be_used) {
        this.be_used = be_used;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public Date getBegan() {
        return began;
    }

    public void setBegan(Date began) {
        this.began = began;
    }

    public Date getEnded() {
        return ended;
    }

    public void setEnded(Date ended) {
        this.ended = ended;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public String getCar_number() {
        return car_number;
    }

    public void setCar_number(String car_number) {
        this.car_number = car_number;
    }
}
