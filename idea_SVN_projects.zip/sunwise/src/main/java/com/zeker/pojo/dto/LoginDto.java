package com.zeker.pojo.dto;

import javax.validation.constraints.Pattern;

/**
 * Created by zeker on 2022/2/7 20:36
 *
 * @Description
 */
public class LoginDto {

    @Pattern(regexp = "^[A-Za-z0-9]{5,20}$",message = "用户名不合法")
    private String username;

    @Pattern(regexp = "^[A-Za-z0-9]{5,20}$",message = "密码不合法")
    private String password;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
