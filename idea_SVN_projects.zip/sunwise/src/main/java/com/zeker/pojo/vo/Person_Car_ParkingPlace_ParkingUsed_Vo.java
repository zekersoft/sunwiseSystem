package com.zeker.pojo.vo;

import java.util.Date;

/**
 * Created by zeker on 2022/2/13 23:27
 *
 * @Description
 */
public class Person_Car_ParkingPlace_ParkingUsed_Vo extends QueryVo {

    private Date began;

    private Date ended;

    private String title;

    public Date getBegan() {
        return began;
    }

    public void setBegan(Date began) {
        this.began = began;
    }

    public Date getEnded() {
        return ended;
    }

    public void setEnded(Date ended) {
        this.ended = ended;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
