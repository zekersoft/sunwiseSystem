package com.zeker.pojo.vo;

public class VillageVo extends QueryVo {

    private String name;//小区名称

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
