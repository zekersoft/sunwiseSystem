package com.zeker.pojo.vo;

public class AdminVo extends QueryVo {

    private String name;//用户姓名

    private String phone;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
