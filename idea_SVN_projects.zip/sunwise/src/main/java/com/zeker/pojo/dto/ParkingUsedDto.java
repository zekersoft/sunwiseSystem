package com.zeker.pojo.dto;

import java.util.Date;

/**
 * Created by zeker on 2022/2/13 23:42
 *
 * @Description
 */
public class ParkingUsedDto {

    private Long id;

    private Long villageId;//小区id

    private String villageName;//小区名称

    private Long parkingPlaceId;

    private String parkingNumber;//车位编号

    private Long carId;

    private String carNumber;//车牌号

    private String carPhoto;//车辆照

    private Long personId;

    private String personName;//车辆所有人

    private String personPhone;//联系方式

    private String be_used;//使用性质

    private double cost;//费用

    private Date began;

    private Date ended;

    private Date created;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getVillageId() {
        return villageId;
    }

    public void setVillageId(Long villageId) {
        this.villageId = villageId;
    }

    public String getVillageName() {
        return villageName;
    }

    public void setVillageName(String villageName) {
        this.villageName = villageName;
    }

    public Long getParkingPlaceId() {
        return parkingPlaceId;
    }

    public void setParkingPlaceId(Long parkingPlaceId) {
        this.parkingPlaceId = parkingPlaceId;
    }

    public String getParkingNumber() {
        return parkingNumber;
    }

    public void setParkingNumber(String parkingNumber) {
        this.parkingNumber = parkingNumber;
    }

    public Long getCarId() {
        return carId;
    }

    public void setCarId(Long carId) {
        this.carId = carId;
    }

    public String getCarNumber() {
        return carNumber;
    }

    public void setCarNumber(String carNumber) {
        this.carNumber = carNumber;
    }

    public String getCarPhoto() {
        return carPhoto;
    }

    public void setCarPhoto(String carPhoto) {
        this.carPhoto = carPhoto;
    }

    public Long getPersonId() {
        return personId;
    }

    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getPersonPhone() {
        return personPhone;
    }

    public void setPersonPhone(String personPhone) {
        this.personPhone = personPhone;
    }

    public String getBe_used() {
        return be_used;
    }

    public void setBe_used(String be_used) {
        this.be_used = be_used;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public Date getBegan() {
        return began;
    }

    public void setBegan(Date began) {
        this.began = began;
    }

    public Date getEnded() {
        return ended;
    }

    public void setEnded(Date ended) {
        this.ended = ended;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }
}
