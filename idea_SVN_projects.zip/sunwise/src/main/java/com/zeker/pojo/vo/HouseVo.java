package com.zeker.pojo.vo;

/**
 * Created by zeker on 2022/2/4 23:54
 *
 * @Description
 */
public class HouseVo extends QueryVo{

    private String villageName;//小区名称

    private String houseName;//房产名称

    private String ownerName;//户主名称

    public String getVillageName() {
        return villageName;
    }

    public void setVillageName(String villageName) {
        this.villageName = villageName;
    }

    public String getHouseName() {
        return houseName;
    }

    public void setHouseName(String houseName) {
        this.houseName = houseName;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }
}
