package com.zeker.pojo.vo;

public class PermissionVo extends QueryVo {

    private String name;//权限名


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
