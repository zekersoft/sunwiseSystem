package com.zeker.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.util.Date;

//如果表名与pojo类名不一致，需要在这里进行注解，跟上表名
@TableName("zeker_village")
public class Village implements Serializable {

    @TableId(type = IdType.INPUT)//必须这样写主键生成策略，才能自动识别
    private Long id;//Long是大写开头，别搞成小写去了

    private String name;

    private String number;

    private String address;

    @TableField("total_buildings")//属性名与数据库不一致，也需要配
    private Integer totalBuildings;

    @TableField("total_households")
    private Integer totalHouseholds;

    private String image;

    @TableField("tenement_name")
    private String tenementName;

    private Date created;

    private Date updated;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Integer getTotalBuildings() {
        return totalBuildings;
    }

    public void setTotalBuildings(Integer totalBuildings) {
        this.totalBuildings = totalBuildings;
    }

    public Integer getTotalHouseholds() {
        return totalHouseholds;
    }

    public void setTotalHouseholds(Integer totalHouseholds) {
        this.totalHouseholds = totalHouseholds;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getTenementName() {
        return tenementName;
    }

    public void setTenementName(String tenementName) {
        this.tenementName = tenementName;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    public Village(Long id, String name, String number, String address, Integer totalBuildings, Integer totalHouseholds, String image, String tenementName, Date created, Date updated) {
        this.id = id;
        this.name = name;
        this.number = number;
        this.address = address;
        this.totalBuildings = totalBuildings;
        this.totalHouseholds = totalHouseholds;
        this.image = image;
        this.tenementName = tenementName;
        this.created = created;
        this.updated = updated;
    }

    public Village() {
    }

    @Override
    public String toString() {
        return "Village{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", number='" + number + '\'' +
                ", address='" + address + '\'' +
                ", totalBuildings=" + totalBuildings +
                ", totalHouseholds=" + totalHouseholds +
                ", image='" + image + '\'' +
                ", tenementName='" + tenementName + '\'' +
                ", created=" + created +
                ", updated=" + updated +
                '}';
    }
}
