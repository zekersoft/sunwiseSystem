package com.zeker.pojo.vo;

public class BuildingVo extends QueryVo {

    private  String buildingName; //楼栋名称

    private String villageName;//小区名称

    public String getBuildingName() {
        return buildingName;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }

    public String getVillageName() {
        return villageName;
    }

    public void setVillageName(String villageName) {
        this.villageName = villageName;
    }
}
