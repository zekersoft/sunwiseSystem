package com.zeker.pojo.vo;

public class RoleVo extends QueryVo {

    private String name;//角色名


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
