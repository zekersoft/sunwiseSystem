package com.zeker.pojo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;

/**
 * Created by zeker on 2022/2/16 2:21
 *
 * @Description
 */

@TableName("zeker_role_permission")
public class RolePermission implements Serializable {


    @TableField("role_id")
    private Long roleId;

    @TableField("permission_id")
    private Long PermissionId;

    public Long getRoleId() {
        return roleId;
    }

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    public Long getPermissionId() {
        return PermissionId;
    }

    public void setPermissionId(Long permissionId) {
        PermissionId = permissionId;
    }
}
